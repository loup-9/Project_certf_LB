package com.example.foodservicelb.Adaptor

import android.content.Context
import android.graphics.drawable.DrawableContainer
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.RelativeLayout
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.RecyclerView
import com.example.foodservicelb.R

class MyViewPagerAdapter (var context: Context) : RecyclerView.Adapter<MyViewPagerAdapter.MyViewOlder>(){
  var color_icon_matrix = arrayOf<IntArray>(
      intArrayOf(android.R.color.holo_red_dark,R.drawable.commande1),
      intArrayOf(android.R.color.holo_blue_dark,R.drawable.commande2),
      intArrayOf(android.R.color.holo_green_dark,R.drawable.commande3)
  )

    class MyViewOlder (itemView: View): RecyclerView.ViewHolder(itemView){
        lateinit var img_view : ImageView
        lateinit var container: RelativeLayout

        init {
            img_view = itemView.findViewById(R.id.img_view) as ImageView
            container = itemView.findViewById(R.id.container) as RelativeLayout
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewOlder {
        return MyViewOlder(LayoutInflater.from(context).inflate(R.layout.order1,parent,false))
    }

    override fun onBindViewHolder(holder: MyViewOlder, position: Int) {
        holder.img_view.setImageResource(color_icon_matrix[position][1])
        holder.container.setBackgroundResource(color_icon_matrix[position][0])
    }

    override fun getItemCount(): Int {
        return color_icon_matrix.size
    }

}