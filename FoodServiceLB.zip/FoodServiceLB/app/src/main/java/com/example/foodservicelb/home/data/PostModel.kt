package com.example.foodservicelb.home.data

data class PostModel (
    var idMeal:Int?=0,
    var strMeal:String?="",
    var strArea:String?=""
)