package com.example.foodservicelb.home.ui

import android.app.Dialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.viewpager2.widget.ViewPager2
import com.example.foodservicelb.Adaptor.MyViewPagerAdapter
import com.example.foodservicelb.R
import com.example.foodservicelb.home.data.PostModel
import com.example.foodservicelb.home.viewmodel.HomeViewModel
import com.example.foodservicelb.home.ui.HomeAdapter
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.tabs.TabLayoutMediator
import okhttp3.*
import java.io.IOException

import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity(), HomeAdapter.HomeListener {

    private lateinit var vm: HomeViewModel
    private lateinit var adapter: HomeAdapter
    private val client = OkHttpClient()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        vm = ViewModelProvider(this)[HomeViewModel::class.java]

        vm.fetchAllPosts()

        run("https://tp-android.herokuapp.com/orders")

        init()
    }

    private fun init() {
        view_pager.adapter = MyViewPagerAdapter(this@MainActivity)
        TabLayoutMediator(tabDots,view_pager,
            TabLayoutMediator.TabConfigurationStrategy({ tab, position -> })
        ).attach()
        view_pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback(){
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                Snackbar.make(parent_view,"you are selected"+(position+1),Snackbar.LENGTH_SHORT).show()
            }
        })
    }


    fun run (url: String){
        val request = Request.Builder()
            .url(url)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {}
            override fun onResponse(call: Call, response: Response) = println(response.body()?.string())
        })
    }


    override fun onItemDeleted(postModel: PostModel, position: Int) {
        postModel.idMeal?.let { vm.deletePost(it) }
        vm.deletePostLiveData?.observe(this, Observer {
            if (it!=null){
                adapter.removeData(position)
            }else{
                showToast("Cannot delete post at the moment!")
            }
        })

    }

    private fun showToast(msg:String){
        Toast.makeText(this,msg, Toast.LENGTH_SHORT).show()
    }

}
