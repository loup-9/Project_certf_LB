package com.example.foodservicelb.network

import com.example.foodservicelb.home.data.PostModel
import retrofit2.Call
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.Path

interface ApiInterface {
    @GET("/orders")
    fun fetchALLPosts(): Call<List<PostModel>>

    @DELETE("/orders/{id}")
    fun deletePost(@Path("id") id:Int):Call<String>
}